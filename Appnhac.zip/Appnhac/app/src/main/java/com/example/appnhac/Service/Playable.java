package com.example.appnhac.Service;

public interface Playable {
    void onTrackPrevious();
    void onTrackPlay();
    void onTrackNext();
    void onTrackPause();
}
